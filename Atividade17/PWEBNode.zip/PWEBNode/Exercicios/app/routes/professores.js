/*module.exports = function (app) {
    app.get('/informacao/professores', function (req, res) {
        var mysql = require('mysql');
        var connection = mysql.createConnection({
            host: "185.201.10.52",
            user: "u534119498_aluno",
            password: "Bosta123",
            database: "u534119498_Denilce"
        });
        connection.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
        });
        connection.query('select * from professores', function (err, results) {
            if (err) {
                console.log(err);
                res.send(err);
                return;
            }
            res.render('informacao/professores', { profs: results });
        });

    });
};*/

// para acessar o arquivo de config voltar 1 nivel 
//D:\PWEBNode\Exercicios\app\config 
var dbConnection = require('../config/dbConnection');
module.exports = function (app) {
    app.get('/informacao/professores', function (req, res) {
        var connection = dbConnection(); // executando a funcao 
        connection.query('select * from professores', function (err, results) {
            if (err) {
                console.log(err);
                res.send(err);
                return;
            }
            res.render('informacao/professores', { profs: results });
        });
    });
};
