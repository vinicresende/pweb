var mysql = require('mysql');
module.exports = function () {
    return connection = mysql.createConnection({
        host: "185.201.10.52",
        user: "u534119498_aluno",
        password: "Bosta123",
        database: "u534119498_Denilce"
    });
}
